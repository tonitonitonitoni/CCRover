import cv2  # state of the art computer vision algorithms library
import numpy as np  # fundamental package for scientific computing
import matplotlib.pyplot as plt  # 2D plotting library producing publication quality figures
import pyrealsense2 as rs

pipe = rs.pipeline()
cfg = rs.config()
cfg.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
cfg.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)

# Import colorizer for depth frames
colorizer = rs.colorizer()
# Start streaming
profile=pipe.start(cfg)
try:
    while True:
        # This call waits until a new coherent set of frames is available on a device
        # Calls to get_frame_data(...) and get_frame_timestamp(...) on a device will return stable values until wait_for_frames(...) is called
        frameset = pipe.wait_for_frames()
        # depth_frame = frameset.get_depth_frame()
        color_frame = frameset.get_color_frame()
        if not color_frame: continue
        # Create alignment primitive with color as its target stream:
        align = rs.align(rs.stream.color)
        frameset = align.process(frameset)

        # Update color and depth frames:
        color_frame = frameset.get_color_frame()
        color = np.asanyarray(color_frame.get_data())
        aligned_depth_frame = frameset.get_depth_frame()
        colorized_depth = np.asanyarray(colorizer.colorize(aligned_depth_frame).get_data())

        # Show the two frames together:
        #images = np.hstack((color, colorized_depth))

        height, width = color.shape[:2]
        expected = 300
        aspect = width / height
        resized_image = cv2.resize(color, (round(expected * aspect), expected))
        crop_start = round(expected * (aspect - 1) / 2)
        crop_img = resized_image[0:expected, crop_start:crop_start + expected]

        net = cv2.dnn.readNetFromCaffe("MobileNetSSD_deploy.prototxt", "MobileNetSSD_deploy.caffemodel")
        inScaleFactor = 0.007843
        meanVal = 127.53
        classNames = ("background", "aeroplane", "bicycle", "bird", "boat",
                      "bottle", "bus", "car", "cat", "chair",
                      "cow", "diningtable", "dog", "horse",
                      "motorbike", "person", "pottedplant",
                      "sheep", "sofa", "train", "tvmonitor")

        blob = cv2.dnn.blobFromImage(crop_img, inScaleFactor, (expected, expected), meanVal, False)
        net.setInput(blob, "data")
        detections = net.forward("detection_out")

        label = detections[0, 0, 0, 1]
        conf = detections[0, 0, 0, 2]
        xmin = detections[0, 0, 0, 3]
        ymin = detections[0, 0, 0, 4]
        xmax = detections[0, 0, 0, 5]
        ymax = detections[0, 0, 0, 6]

        print(f'xmin{xmin}, ymin{ymin}, xmax{xmax}, ymax{ymax}')

        className = classNames[int(label)]

        cv2.rectangle(crop_img, (int(xmin * expected), int(ymin * expected)),
                      (int(xmax * expected), int(ymax * expected)), (255, 255, 255), 2)
        cv2.putText(crop_img, className,
                    (int(xmin * expected), int(ymin * expected) - 5),
                    cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255))

        scale = height / expected
        xmin_depth = int((xmin * expected + crop_start) * scale)
        ymin_depth = int((ymin * expected) * scale)
        xmax_depth = int((xmax * expected + crop_start) * scale)
        ymax_depth = int((ymax * expected) * scale)
        print(f'xminD{xmin_depth}, yminD{ymin_depth}, xmaxD{xmax_depth}, ymaxD{ymax_depth}')
        depth = np.asanyarray(aligned_depth_frame.get_data())
        # Crop depth data:
        depth = depth[xmin_depth:xmax_depth, ymin_depth:ymax_depth].astype(float)

        # Get data scale from the device and convert to meters
        depth_scale = profile.get_device().first_depth_sensor().get_depth_scale()
        depth = depth * depth_scale
        dist, _, _, _ = cv2.mean(depth)
        print("Detected a {0} {1:.3} meters away.".format(className, dist))


        # Display output image
        cv2.namedWindow('RealSense', cv2.WINDOW_AUTOSIZE)
        cv2.imshow('RealSense', crop_img)
        key = cv2.waitKey(1)
        # Press esc or 'q' to close the image window
        if key & 0xFF == ord('q') or key == 27:
            cv2.destroyAllWindows()
            break

finally:
    # Stop streaming
    pipe.stop()